let scene, camera, renderer, sphere, sphereMesh, torus, torusMesh;
const shape = [];
function init () {
	scene = new THREE.Scene();
	camera = new THREE.PerspectiveCamera(105,window.innerWidth/window.innerHeight, 1,5000);
	camera.position.z = 1500;

	renderer = new THREE.WebGLRenderer({alpha:true});
	renderer.setSize(window.innerWidth, window.innerHeight);
	renderer.shadowMap.enabled = true;
	renderer.shadowMap.type = THREE.PCFSoftShadowMap;
	renderer.setClearColor( 0xffffff, 0);
	renderer.shadowMapSoft = true;
	renderer.autoClear = false;
	document.body.appendChild(renderer.domElement);	

	window.addEventListener("resize", function () {
	    camera.aspect = window.innerWidth / window.innerHeight;
	    camera.updateProjectionMatrix();
	    renderer.setSize( window.innerWidth, window.innerHeight );
	})

	const  controls = new THREE.OrbitControls( camera,  renderer.domElement);
}