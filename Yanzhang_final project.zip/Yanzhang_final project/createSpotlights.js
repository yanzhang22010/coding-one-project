function createSpotlights() {
	const SpotLightsProps = [
		[0xfc6bcf , 1, 2000,128,0],
		[0x6bd6ff , 1, 2000,120,0,1],
		[0x6bd6ff , 1, 2000,100,0,1],
		[0x6bd6ff , 0.8, 2500,128,0,1]
	]
	const POS_ARR = [
		[0,800,800],
		[700,1000,1000],
		[700,1000,-1000],
		[0,-1300, 1200]
	]
	const spot = [];
	const helper = [];

	for(let x = 0;x < POS_ARR.length; x++) {
		spot[x] = new THREE.SpotLight(...SpotLightsProps[x]);
		spot[x].position.set(...POS_ARR[x])
		spot[x].castShadow = true;
		scene.add(spot[x]);
		spot[x].shadow.mapSize.width = 1024;
		spot[x].shadow.mapSize.height = 1024
		helper[x] = new THREE.SpotLightHelper( spot[x] );
	}
}