function createObj() {

	let sphereMaterialMesh = new THREE.MeshPhongMaterial({
		color      : new THREE.Color("#fff"),
		emissive   : new THREE.Color("#17e439"),
		shininess  : new THREE.Color("#fff"),
		shininess  :  10,
		shading    :  THREE.SmoothShading,
		transparent: 1,
		opacity    : 1,
		wireframe: true
	});

	const geometry2 = new THREE.DodecahedronGeometry( 650, 1);
	sphereMesh = new THREE.Mesh( geometry2, sphereMaterialMesh );
	sphereMesh.receiveShadow = true;
	sphereMesh.castShadow = true;
	scene.add(sphereMesh);

    const sphereMaterial = new THREE.MeshPhongMaterial({
		color      : new THREE.Color("#fff"),
		emissive   : new THREE.Color("#2196f3"),
		shininess  : new THREE.Color("#fc6bcf"),
		shininess  :  10,
		shading    :  THREE.FlatShading,
		transparent: 1,
		opacity    : 1,
		side 	   : THREE.DoubleSide
	});

	const geometry = new THREE.DodecahedronGeometry( 500, 1);
	sphere = new THREE.Mesh( geometry, sphereMaterial );
	sphere.receiveShadow = true;
	sphere.castShadow = true;
	scene.add(sphere );

    let torusMeshMaterial = new THREE.MeshPhongMaterial({
		color      : new THREE.Color("#fff"),
		emissive   : new THREE.Color("#efdc01"),
		shininess  : new THREE.Color("#fff"),
		shininess  :  10,
		shading    :  THREE.FlatShading,
		transparent: 1,
		opacity    : 1,
		wireframe	: true
	});

	const geometryTorus = new THREE.TorusGeometry( 580, 80, 5, 40 );
	torusMesh = new THREE.Mesh( geometryTorus, torusMeshMaterial);
	torusMesh.receiveShadow = true;
	torusMesh.castShadow = true;
	scene.add( torusMesh );

	const torusMaterial = new THREE.MeshPhongMaterial({
		color      : new THREE.Color("#fff"),
		emissive   : new THREE.Color("#1a0ff5"),
		shininess  : new THREE.Color("#fff"),
		shininess  :  10,
		shading    :  THREE.FlatShading,
		transparent: 1,
		opacity    : 1,
		wireframe	: true
	});

	const geometry3 = new THREE.TorusGeometry( 580, 100, 5, 40 );
	torus = new THREE.Mesh( geometry3, torusMaterial );
	torus.receiveShadow = true;
	torus.castShadow = true;
	scene.add( torus );
}