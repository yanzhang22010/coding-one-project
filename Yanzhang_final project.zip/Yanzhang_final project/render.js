function render() {
	requestAnimationFrame(render);
	renderer.render(scene, camera);

    sphere.rotation.y += 0.005
	sphere.rotation.x += 0.005
	sphere.rotation.z += 0.005

	sphereMesh.rotation.y += 0.002
	sphereMesh.rotation.x += 0.002
	sphereMesh.rotation.z += 0.002

	
	torus.rotation.y += 0.05
	torus.rotation.x += 0.01
	torus.rotation.z += 0.05

	torusMesh.rotation.y += 0.01
	torusMesh.rotation.x += 0.05
	torusMesh.rotation.z += 0.01

	for(let x = 0; x< shape.length;x++) {
		shape[x].position.z -= 5

		if(shape[x].position.z < -1000) {
			shape[x].position.z = getRandArbit(0,2000)
		}
	}
}