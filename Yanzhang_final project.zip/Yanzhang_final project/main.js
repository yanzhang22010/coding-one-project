init();
createObj();
createSpotlights();
randomStars();
render();