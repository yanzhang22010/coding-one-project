function randomStars() {
	const rs = [];
	const pos = {
		x : 0,
		y : 0,
		z : 0
	}
	const color = "#fc6bcf";
	let material;
	for(let x = 0; x < 200; x++) {
		material = new THREE.MeshPhongMaterial({
			color      : new THREE.Color("#fff"),
			emissive   : new THREE.Color("#62aae3"),
			shininess  : new THREE.Color("#fff"),
			shininess  :  100,
			shading    :  THREE.FlatShading,
		});
		if(x %2 == 0) {
			material.emissive = new THREE.Color(color);
		}

		pos.x = getRandArbit(-(window.innerWidth+500),window.innerWidth+500);
		pos.y = getRandArbit(-(window.innerHeight+1000),window.innerHeight+1000);
		pos.z = getRandArbit(-1000,2000);

		rs[x] = new THREE.TetrahedronGeometry(getRandArbit(2,20),1);
		shape[x] = new THREE.Mesh(rs[x], material);
		shape[x].castShadow = true;
		shape[x].position.set(pos.x,pos.y,pos.z);
		scene.add(shape[x])
	}
}
function getRandArbit(min, max) {
	return Math.random() * (max - min) + min;
}